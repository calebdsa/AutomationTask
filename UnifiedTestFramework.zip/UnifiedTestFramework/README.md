# Unified API-UI Integration Test Framework

## Overview
This framework provides an end-to-end testing solution that bridges API and UI testing for mobile applications. It creates a user via API, logs in using the same user in the mobile app, and validates that the user profile data shown in the app matches the API response.

## Framework Structure

```
UnifiedTestFramework/
├── src/
│   ├── main/
│   │   └── java/
│   │       └── com/
│   │           └── testing/
│   │               └── framework/
│   │                   ├── api/
│   │                   │   ├── base/
│   │                   │   │   └── ApiBaseTest.java
│   │                   │   ├── models/
│   │                   │   │   └── User.java
│   │                   │   └── services/
│   │                   │       └── UserApiService.java
│   │                   ├── mobile/
│   │                   │   ├── base/
│   │                   │   │   └── MobileBaseTest.java
│   │                   │   └── pages/
│   │                   │       ├── BasePage.java
│   │                   │       ├── LoginPage.java
│   │                   │       └── ProfilePage.java
│   │                   ├── reporting/
│   │                   │   ├── ExtentReportManager.java
│   │                   │   └── TestListener.java
│   │                   └── utils/
│   │                       ├── DataValidator.java
│   │                       └── SchemaValidator.java
│   └── test/
│       ├── java/
│       │   └── com/
│       │       └── testing/
│       │           └── framework/
│       │               └── integration/
│       │                   └── ApiUiIntegrationTest.java
│       └── resources/
│           ├── apps/
│           │   └── TheApp.apk
│           └── testng.xml
└── pom.xml
```

## Key Features

1. **API Testing**
   - User creation, retrieval, and cleanup via API
   - JSON schema validation
   - Request/response logging

2. **Mobile App Automation**
   - Page Object Model implementation
   - Screenshot capture on failure
   - Appium integration

3. **Integration Testing**
   - End-to-end test flow
   - Data validation between API and UI
   - Test data setup and cleanup via APIs

4. **Reporting**
   - ExtentReports integration
   - Test step logging
   - Failure screenshots in reports

## Prerequisites

- Java 11 or higher
- Maven
- Appium Server
- Android Emulator or real device
- TestNG

## Running the Tests

1. Start Appium server
2. Start Android emulator or connect a real device
3. Run the tests using Maven:

```bash
mvn clean test
```

## Test Flow

1. **API Setup**
   - Create a user via API
   - Validate the API response
   - Store user details for later validation

2. **Mobile App Testing**
   - Launch the mobile app
   - Log in using the credentials of the user created via API
   - Navigate to the profile page
   - Capture profile data from the UI

3. **Data Validation**
   - Compare profile data from UI with API response
   - Validate data consistency
   - Log detailed comparison results

4. **Cleanup**
   - Delete the test user via API
   - Generate test report

## Reporting

The framework generates detailed HTML reports using ExtentReports. Reports include:
- Test steps with timestamps
- Pass/fail status for each step
- Screenshots for failures
- Detailed data comparison results

Reports are generated in the `test-output` directory.
