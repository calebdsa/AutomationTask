package com.testing.framework.reporting;

import com.aventstack.extentreports.Status;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

/**
 * TestNG listener for automatic reporting
 */
public class TestListener implements ITestListener {
    private static final Logger logger = LogManager.getLogger(TestListener.class);

    @Override
    public void onStart(ITestContext context) {
        logger.info("Starting test suite: " + context.getName());
        ExtentReportManager.initReports();
    }

    @Override
    public void onTestStart(ITestResult result) {
        logger.info("Starting test: " + result.getName());
        ExtentReportManager.createTest(result.getMethod().getMethodName());
        ExtentReportManager.logStep(Status.INFO, "Test started: " + result.getName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        logger.info("Test passed: " + result.getName());
        ExtentReportManager.logStep(Status.PASS, "Test passed: " + result.getName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        logger.error("Test failed: " + result.getName());
        ExtentReportManager.logStep(Status.FAIL, "Test failed: " + result.getName());
        
        // Log exception details if available
        if (result.getThrowable() != null) {
            ExtentReportManager.logStep(Status.FAIL, "Exception: " + result.getThrowable().getMessage());
            logger.error("Exception: " + result.getThrowable().getMessage(), result.getThrowable());
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        logger.warn("Test skipped: " + result.getName());
        ExtentReportManager.logStep(Status.SKIP, "Test skipped: " + result.getName());
    }

    @Override
    public void onFinish(ITestContext context) {
        logger.info("Finishing test suite: " + context.getName());
        ExtentReportManager.flushReports();
    }
}
