package com.testing.framework.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.util.HashMap;
import java.util.Map;

/**
 * Utility class for data validation between API and UI
 */
public class DataValidator {
    private static final Logger logger = LogManager.getLogger(DataValidator.class);
    
    /**
     * Validate that two data sets match
     * @param apiData Map of API data
     * @param uiData Map of UI data
     * @return true if all data matches, false otherwise
     */
    public static boolean validateDataConsistency(Map<String, String> apiData, Map<String, String> uiData) {
        logger.info("Validating data consistency between API and UI");
        
        boolean allMatch = true;
        for (Map.Entry<String, String> entry : apiData.entrySet()) {
            String key = entry.getKey();
            String apiValue = entry.getValue();
            String uiValue = uiData.get(key);
            
            if (uiValue == null) {
                logger.error("Field '" + key + "' not found in UI data");
                allMatch = false;
                continue;
            }
            
            if (!apiValue.equals(uiValue)) {
                logger.error("Data mismatch for field '" + key + "': API=" + apiValue + ", UI=" + uiValue);
                allMatch = false;
            } else {
                logger.info("Data match for field '" + key + "': " + apiValue);
            }
        }
        
        if (allMatch) {
            logger.info("All data fields match between API and UI");
        } else {
            logger.error("Data inconsistency detected between API and UI");
        }
        
        return allMatch;
    }
    
    /**
     * Assert that two data sets match and throw assertion error if not
     * @param apiData Map of API data
     * @param uiData Map of UI data
     * @param message Message for assertion failure
     */
    public static void assertDataConsistency(Map<String, String> apiData, Map<String, String> uiData, String message) {
        boolean consistent = validateDataConsistency(apiData, uiData);
        Assert.assertTrue(consistent, message);
    }
    
    /**
     * Create a data map from individual fields
     * @param fieldNames Array of field names
     * @param fieldValues Array of field values
     * @return Map of field names to values
     */
    public static Map<String, String> createDataMap(String[] fieldNames, String[] fieldValues) {
        if (fieldNames.length != fieldValues.length) {
            logger.error("Field names and values arrays must be the same length");
            throw new IllegalArgumentException("Field names and values arrays must be the same length");
        }
        
        Map<String, String> dataMap = new HashMap<>();
        for (int i = 0; i < fieldNames.length; i++) {
            dataMap.put(fieldNames[i], fieldValues[i]);
        }
        
        return dataMap;
    }
}
