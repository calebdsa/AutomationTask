package com.testing.framework.api.services;

import com.testing.framework.api.models.User;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

import static io.restassured.RestAssured.given;

/**
 * Service class for user-related API operations
 */
public class UserApiService {
    private static final Logger logger = LogManager.getLogger(UserApiService.class);
    
    /**
     * Create a new user via API
     * @param user User object with required data
     * @return Response object containing API response
     */
    public Response createUser(User user) {
        logger.info("Creating user: " + user.getName());
        
        JSONObject requestParams = new JSONObject();
        requestParams.put("name", user.getName());
        requestParams.put("job", user.getJob());
        
        Response response = given()
                .header("Content-Type", "application/json")
                .body(requestParams.toString())
                .when()
                .post("/users");
        
        // Extract user ID from response and set it in the user object
        if (response.statusCode() == 201) {
            String userId = response.jsonPath().getString("id");
            user.setId(userId);
            user.setCreatedAt(response.jsonPath().getString("createdAt"));
            logger.info("User created successfully with ID: " + userId);
        } else {
            logger.error("Failed to create user. Status code: " + response.statusCode());
        }
        
        return response;
    }
    
    /**
     * Get user details by ID
     * @param userId User ID
     * @return Response object containing API response
     */
    public Response getUserById(String userId) {
        logger.info("Getting user with ID: " + userId);
        
        Response response = given()
                .when()
                .get("/users/" + userId);
        
        if (response.statusCode() == 200) {
            logger.info("User retrieved successfully");
        } else {
            logger.error("Failed to retrieve user. Status code: " + response.statusCode());
        }
        
        return response;
    }
    
    /**
     * Update existing user
     * @param user User object with updated data
     * @return Response object containing API response
     */
    public Response updateUser(User user) {
        logger.info("Updating user with ID: " + user.getId());
        
        JSONObject requestParams = new JSONObject();
        requestParams.put("name", user.getName());
        requestParams.put("job", user.getJob());
        
        Response response = given()
                .header("Content-Type", "application/json")
                .body(requestParams.toString())
                .when()
                .put("/users/" + user.getId());
        
        if (response.statusCode() == 200) {
            user.setUpdatedAt(response.jsonPath().getString("updatedAt"));
            logger.info("User updated successfully");
        } else {
            logger.error("Failed to update user. Status code: " + response.statusCode());
        }
        
        return response;
    }
    
    /**
     * Delete user by ID
     * @param userId User ID
     * @return Response object containing API response
     */
    public Response deleteUser(String userId) {
        logger.info("Deleting user with ID: " + userId);
        
        Response response = given()
                .when()
                .delete("/users/" + userId);
        
        if (response.statusCode() == 204) {
            logger.info("User deleted successfully");
        } else {
            logger.error("Failed to delete user. Status code: " + response.statusCode());
        }
        
        return response;
    }
    
    /**
     * Login user and retrieve authentication token
     * @param user User object with login credentials
     * @return Response object containing API response
     */
    public Response loginUser(User user) {
        logger.info("Logging in user: " + user.getEmail());
        
        JSONObject loginCredentials = new JSONObject();
        loginCredentials.put("email", user.getEmail());
        loginCredentials.put("password", user.getPassword());
        
        Response response = given()
                .header("Content-Type", "application/json")
                .body(loginCredentials.toString())
                .when()
                .post("/login");
        
        if (response.statusCode() == 200) {
            String token = response.jsonPath().getString("token");
            user.setToken(token);
            logger.info("User logged in successfully");
        } else {
            logger.error("Failed to login user. Status code: " + response.statusCode());
        }
        
        return response;
    }
    
    /**
     * Map API response to User object
     * @param response API response
     * @return User object populated with data from response
     */
    public User mapResponseToUser(Response response) {
        User user = new User();
        
        try {
            if (response.jsonPath().get("data") != null) {
                // Single user response format
                user.setId(response.jsonPath().getString("data.id"));
                user.setEmail(response.jsonPath().getString("data.email"));
                user.setFirstName(response.jsonPath().getString("data.first_name"));
                user.setLastName(response.jsonPath().getString("data.last_name"));
                user.setAvatar(response.jsonPath().getString("data.avatar"));
                
                // Combine first and last name for the name field
                user.setName(user.getFirstName() + " " + user.getLastName());
            } else {
                // Create/update user response format
                if (response.jsonPath().get("id") != null) {
                    user.setId(response.jsonPath().getString("id"));
                }
                if (response.jsonPath().get("name") != null) {
                    user.setName(response.jsonPath().getString("name"));
                }
                if (response.jsonPath().get("job") != null) {
                    user.setJob(response.jsonPath().getString("job"));
                }
                if (response.jsonPath().get("createdAt") != null) {
                    user.setCreatedAt(response.jsonPath().getString("createdAt"));
                }
                if (response.jsonPath().get("updatedAt") != null) {
                    user.setUpdatedAt(response.jsonPath().getString("updatedAt"));
                }
            }
            
            logger.info("Response mapped to User object successfully");
        } catch (Exception e) {
            logger.error("Error mapping response to User object: " + e.getMessage());
        }
        
        return user;
    }
}
