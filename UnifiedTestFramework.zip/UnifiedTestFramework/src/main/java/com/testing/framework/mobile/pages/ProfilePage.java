package com.testing.framework.mobile.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;

/**
 * Page object for the profile screen in MyDemoApp
 */
public class ProfilePage extends BasePage {
    private static final Logger logger = LogManager.getLogger(ProfilePage.class);
    
    // Updated locators for MyDemoApp
    @AndroidFindBy(accessibility = "container header")
    private WebElement profileHeader;
    
    @AndroidFindBy(accessibility = "Username display")
    private WebElement userNameField;
    
    @AndroidFindBy(accessibility = "Password display")
    private WebElement passwordField;
    
    @AndroidFindBy(accessibility = "Email display")
    private WebElement userEmailField;
    
    @AndroidFindBy(accessibility = "Name display")
    private WebElement userFullNameField;
    
    @AndroidFindBy(accessibility = "Log out button")
    private WebElement logoutButton;
    
    @AndroidFindBy(accessibility = "Menu")
    private WebElement menuButton;
    
    /**
     * Constructor for ProfilePage
     * @param driver AppiumDriver instance
     */
    public ProfilePage(AppiumDriver driver) {
        super(driver);
        logger.info("Profile page initialized");
    }
    
    /**
     * Check if profile page is displayed
     * @return true if profile page is displayed, false otherwise
     */
    public boolean isProfilePageDisplayed() {
        logger.info("Checking if profile page is displayed");
        return isDisplayed(profileHeader) && isDisplayed(userNameField);
    }
    
    /**
     * Get user ID from profile (using username as ID in MyDemoApp)
     * @return User ID text
     */
    public String getUserId() {
        logger.info("Getting user ID from profile (using username)");
        return getText(userNameField);
    }
    
    /**
     * Get user name from profile
     * @return User name text
     */
    public String getUserName() {
        logger.info("Getting user name from profile");
        return getText(userNameField);
    }
    
    /**
     * Get user email from profile
     * @return User email text
     */
    public String getUserEmail() {
        logger.info("Getting user email from profile");
        return getText(userEmailField);
    }
    
    /**
     * Get user first name from profile (extracting from full name)
     * @return User first name text
     */
    public String getUserFirstName() {
        logger.info("Getting user first name from profile");
        String fullName = getText(userFullNameField);
        return fullName.contains(" ") ? fullName.split(" ")[0] : fullName;
    }
    
    /**
     * Get user last name from profile (extracting from full name)
     * @return User last name text
     */
    public String getUserLastName() {
        logger.info("Getting user last name from profile");
        String fullName = getText(userFullNameField);
        return fullName.contains(" ") ? fullName.split(" ")[1] : "";
    }
    
    /**
     * Click logout button
     * @return LoginPage instance
     */
    public LoginPage clickLogout() {
        logger.info("Clicking logout button");
        click(logoutButton);
        return new LoginPage(driver);
    }
}
