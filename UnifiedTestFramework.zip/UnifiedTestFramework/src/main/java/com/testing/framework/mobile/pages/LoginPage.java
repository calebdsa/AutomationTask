package com.testing.framework.mobile.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;

/**
 * Page object for the login screen of MyDemoApp
 */
public class LoginPage extends BasePage {
    private static final Logger logger = LogManager.getLogger(LoginPage.class);
    
    // Updated locators for MyDemoApp
    @AndroidFindBy(accessibility = "Username input field")
    private WebElement usernameField;
    
    @AndroidFindBy(accessibility = "Password input field")
    private WebElement passwordField;
    
    @AndroidFindBy(accessibility = "Login button")
    private WebElement loginButton;
    
    @AndroidFindBy(accessibility = "Menu")
    private WebElement menuButton;
    
    @AndroidFindBy(accessibility = "menu item log in")
    private WebElement menuLoginItem;
    
    @AndroidFindBy(id = "android:id/message")
    private WebElement errorMessage;
    
    /**
     * Constructor for LoginPage
     * @param driver AppiumDriver instance
     */
    public LoginPage(AppiumDriver driver) {
        super(driver);
        logger.info("Login page initialized");
    }
    
    /**
     * Navigate to login screen via menu
     * @return LoginPage instance for method chaining
     */
    public LoginPage navigateToLogin() {
        logger.info("Navigating to login screen");
        click(menuButton);
        click(menuLoginItem);
        return this;
    }
    
    /**
     * Enter username
     * @param username Username to enter
     * @return LoginPage instance for method chaining
     */
    public LoginPage enterUsername(String username) {
        logger.info("Entering username: " + username);
        sendKeys(usernameField, username);
        return this;
    }
    
    /**
     * Enter password
     * @param password Password to enter
     * @return LoginPage instance for method chaining
     */
    public LoginPage enterPassword(String password) {
        logger.info("Entering password");
        sendKeys(passwordField, password);
        return this;
    }
    
    /**
     * Click login button
     * @return ProfilePage instance if login successful
     */
    public ProfilePage clickLogin() {
        logger.info("Clicking login button");
        click(loginButton);
        return new ProfilePage(driver);
    }
    
    /**
     * Perform login with credentials
     * @param username Username to use
     * @param password Password to use
     * @return ProfilePage instance if login successful
     */
    public ProfilePage login(String username, String password) {
        logger.info("Performing login with username: " + username);
        navigateToLogin();
        enterUsername(username);
        enterPassword(password);
        return clickLogin();
    }
    
    /**
     * Get error message text
     * @return Error message text
     */
    public String getErrorMessage() {
        logger.info("Getting error message");
        return getText(errorMessage);
    }
    
    /**
     * Check if error message is displayed
     * @return true if error message is displayed, false otherwise
     */
    public boolean isErrorMessageDisplayed() {
        return isDisplayed(errorMessage);
    }
    
    /**
     * Check if login page is displayed
     * @return true if login page is displayed, false otherwise
     */
    public boolean isLoginPageDisplayed() {
        logger.info("Checking if login page is displayed");
        // First check if we're on the main screen with menu button
        if (isDisplayed(menuButton)) {
            // Navigate to login screen
            navigateToLogin();
        }
        return isDisplayed(usernameField) && isDisplayed(passwordField) && isDisplayed(loginButton);
    }
}
