package com.testing.framework.utils;

import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Utility class for JSON schema validation
 */
public class SchemaValidator {
    private static final Logger logger = LogManager.getLogger(SchemaValidator.class);
    
    /**
     * Validate user schema for single user response
     * @param response API response to validate
     */
    public static void validateUserSchema(Response response) {
        String userSchema = "{" +
                "\"$schema\": \"http://json-schema.org/draft-04/schema#\"," +
                "\"type\": \"object\"," +
                "\"properties\": {" +
                "\"data\": {" +
                "\"type\": \"object\"," +
                "\"properties\": {" +
                "\"id\": {\"type\": \"integer\"}," +
                "\"email\": {\"type\": \"string\"}," +
                "\"first_name\": {\"type\": \"string\"}," +
                "\"last_name\": {\"type\": \"string\"}," +
                "\"avatar\": {\"type\": \"string\"}" +
                "}," +
                "\"required\": [\"id\", \"email\", \"first_name\", \"last_name\", \"avatar\"]" +
                "}" +
                "}," +
                "\"required\": [\"data\"]" +
                "}";
        
        try {
            response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(userSchema));
            logger.info("User schema validation successful");
        } catch (Exception e) {
            logger.error("User schema validation failed: " + e.getMessage());
            throw e;
        }
    }
    
    /**
     * Validate schema for user creation response
     * @param response API response to validate
     */
    public static void validateCreateUserSchema(Response response) {
        String createUserSchema = "{" +
                "\"$schema\": \"http://json-schema.org/draft-04/schema#\"," +
                "\"type\": \"object\"," +
                "\"properties\": {" +
                "\"name\": {\"type\": \"string\"}," +
                "\"job\": {\"type\": \"string\"}," +
                "\"id\": {\"type\": \"string\"}," +
                "\"createdAt\": {\"type\": \"string\"}" +
                "}," +
                "\"required\": [\"name\", \"job\", \"id\", \"createdAt\"]" +
                "}";
        
        try {
            response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(createUserSchema));
            logger.info("Create user schema validation successful");
        } catch (Exception e) {
            logger.error("Create user schema validation failed: " + e.getMessage());
            throw e;
        }
    }
    
    /**
     * Validate schema for user list response
     * @param response API response to validate
     */
    public static void validateListUsersSchema(Response response) {
        String listUsersSchema = "{" +
                "\"$schema\": \"http://json-schema.org/draft-04/schema#\"," +
                "\"type\": \"object\"," +
                "\"properties\": {" +
                "\"page\": {\"type\": \"integer\"}," +
                "\"per_page\": {\"type\": \"integer\"}," +
                "\"total\": {\"type\": \"integer\"}," +
                "\"total_pages\": {\"type\": \"integer\"}," +
                "\"data\": {" +
                "\"type\": \"array\"," +
                "\"items\": {" +
                "\"type\": \"object\"," +
                "\"properties\": {" +
                "\"id\": {\"type\": \"integer\"}," +
                "\"email\": {\"type\": \"string\"}," +
                "\"first_name\": {\"type\": \"string\"}," +
                "\"last_name\": {\"type\": \"string\"}," +
                "\"avatar\": {\"type\": \"string\"}" +
                "}," +
                "\"required\": [\"id\", \"email\", \"first_name\", \"last_name\", \"avatar\"]" +
                "}" +
                "}," +
                "\"support\": {" +
                "\"type\": \"object\"," +
                "\"properties\": {" +
                "\"url\": {\"type\": \"string\"}," +
                "\"text\": {\"type\": \"string\"}" +
                "}," +
                "\"required\": [\"url\", \"text\"]" +
                "}" +
                "}," +
                "\"required\": [\"page\", \"per_page\", \"total\", \"total_pages\", \"data\", \"support\"]" +
                "}";
        try {
            response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(listUsersSchema));
            logger.info("List users schema validation successful");
        } catch (Exception e) {
            logger.error("List users schema validation failed: " + e.getMessage());
            throw e;
        }
    }
    
    /**
     * Validate schema for login response
     * @param response API response to validate
     */
    public static void validateLoginSchema(Response response) {
        String loginSchema = "{" +
                "\"$schema\": \"http://json-schema.org/draft-04/schema#\"," +
                "\"type\": \"object\"," +
                "\"properties\": {" +
                "\"token\": {\"type\": \"string\"}" +
                "}," +
                "\"required\": [\"token\"]" +
                "}";
        
        try {
            response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(loginSchema));
            logger.info("Login schema validation successful");
        } catch (Exception e) {
            logger.error("Login schema validation failed: " + e.getMessage());
            throw e;
        }
    }
}
