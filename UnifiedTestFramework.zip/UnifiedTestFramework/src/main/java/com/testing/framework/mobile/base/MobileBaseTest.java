package com.testing.framework.mobile.base;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import java.io.File;
import java.io.IOException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

/**
 * Base class for mobile tests providing common functionality
 * for Appium driver setup, screenshot capture, and cleanup
 */
public class MobileBaseTest {
    protected static final Logger logger = LogManager.getLogger(MobileBaseTest.class);
    protected static AppiumDriver driver;
    protected static final String SCREENSHOTS_DIR = "test-output/screenshots/";
    // Updated to use Appium 2.x URL format (without /wd/hub)
    protected static final String APPIUM_SERVER_URL = "http://localhost:4723";
    protected static final int CONNECTION_TIMEOUT = 5000; // 5 seconds
    
    /**
     * Check if Appium server is running
     * @return true if server is running, false otherwise
     */
    protected boolean isAppiumServerRunning() {
        try {
            URL url = new URL(APPIUM_SERVER_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(CONNECTION_TIMEOUT);
            connection.setReadTimeout(CONNECTION_TIMEOUT);
            connection.setRequestMethod("GET");
            
            try {
                connection.connect();
                return true;
            } catch (ConnectException e) {
                logger.error("Appium server is not running at " + APPIUM_SERVER_URL);
                return false;
            } finally {
                connection.disconnect();
            }
        } catch (Exception e) {
            logger.error("Error checking Appium server: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Check if the app file exists
     * @param appPath Path to the app file
     * @return true if file exists, false otherwise
     */
    protected boolean doesAppFileExist(String appPath) {
        File appFile = new File(appPath);
        boolean exists = appFile.exists();
        if (!exists) {
            logger.error("App file not found at: " + appPath);
        }
        return exists;
    }
    
    @BeforeSuite
    public void setupAppium() throws Exception {
        logger.info("Setting up Appium driver");
        
        // Create screenshots directory if it doesn't exist
        File screenshotsDir = new File(SCREENSHOTS_DIR);
        if (!screenshotsDir.exists()) {
            screenshotsDir.mkdirs();
        }
        
        // Check if Appium server is running
        if (!isAppiumServerRunning()) {
            String errorMessage = "Appium server is not running at " + APPIUM_SERVER_URL + 
                                 ". Please start the Appium server before running tests.";
            logger.error(errorMessage);
            throw new SkipException(errorMessage);
        }
        
        // Set up app path - Updated to use MyDemoApp.apk
        String appPath = System.getProperty("user.dir") + "/src/test/resources/apps/MyDemoApp.apk";
        
        // Check if app file exists
        if (!doesAppFileExist(appPath)) {
            String errorMessage = "App file not found at: " + appPath + 
                                 ". Please ensure the app file exists before running tests.";
            logger.error(errorMessage);
            throw new SkipException(errorMessage);
        }
        
        // Set up desired capabilities for Android
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
        capabilities.setCapability(MobileCapabilityType.APP, appPath);
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 60);
        
        // Initialize the driver
        try {
            // Updated URL to match Appium 2.x format
            driver = new AndroidDriver(new URL(APPIUM_SERVER_URL), capabilities);
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            logger.info("Appium driver initialized successfully");
        } catch (Exception e) {
            String errorMessage = "Failed to initialize Appium driver: " + e.getMessage() + 
                                 "\nPlease ensure that:\n" +
                                 "1. Appium server is running at " + APPIUM_SERVER_URL + "\n" +
                                 "2. Android emulator or device is connected and available\n" +
                                 "3. The app file exists at: " + appPath;
            logger.error(errorMessage);
            throw new SkipException(errorMessage);
        }
    }
    
    @AfterMethod
    public void captureScreenshotOnFailure(ITestResult result) {
        if (driver != null && result.getStatus() == ITestResult.FAILURE) {
            logger.info("Test failed. Capturing screenshot");
            captureScreenshot(result.getName());
        }
    }
    
    @AfterSuite
    public void tearDown() {
        if (driver != null) {
            logger.info("Closing Appium driver");
            driver.quit();
        }
    }
    
    /**
     * Capture screenshot and save to file
     * @param testName Name of the test for screenshot filename
     * @return Path to the saved screenshot file
     */
    protected String captureScreenshot(String testName) {
        if (driver == null) {
            logger.error("Cannot capture screenshot: driver is null");
            return null;
        }
        
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String screenshotFileName = testName + "_" + timestamp + ".png";
        String screenshotPath = SCREENSHOTS_DIR + screenshotFileName;
        
        try {
            File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenshotFile, new File(screenshotPath));
            logger.info("Screenshot saved to: " + screenshotPath);
            return screenshotPath;
        } catch (IOException e) {
            logger.error("Failed to capture screenshot: " + e.getMessage());
            return null;
        }
    }
}
