package com.testing.framework.api.models;

/**
 * User model class representing user data for API operations
 */
public class User {
    private String id;
    private String name;
    private String job;
    private String email;
    private String password;
    private String firstName;
    private String lastName;
    private String avatar;
    private String createdAt;
    private String updatedAt;
    private String token;

    // Default constructor
    public User() {
    }

    // Constructor with essential fields
    public User(String field1, String field2, UserType type) {
        if (type == UserType.CREATE) {
            this.name = field1;
            this.job = field2;
        } else if (type == UserType.LOGIN) {
            this.email = field1;
            this.password = field2;
        }
    }

    // Full constructor
    public User(String id, String name, String job, String email, String firstName, String lastName, String avatar) {
        this.id = id;
        this.name = name;
        this.job = job;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.avatar = avatar;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", job='" + job + '\'' +
                ", email='" + email + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", avatar='" + avatar + '\'' +
                '}';
    }

    /**
     * Enum to specify the type of user creation
     */
    public enum UserType {
        CREATE,  // For creating a new user with name and job
        LOGIN    // For login with email and password
    }
}
