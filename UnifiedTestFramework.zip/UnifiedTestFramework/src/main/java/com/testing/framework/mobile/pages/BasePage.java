package com.testing.framework.mobile.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Base class for all page objects in the mobile app
 */
public abstract class BasePage {
    protected static final Logger logger = LogManager.getLogger(BasePage.class);
    protected AppiumDriver driver;
    protected WebDriverWait wait;
    
    /**
     * Constructor for BasePage
     * @param driver AppiumDriver instance
     */
    public BasePage(AppiumDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        logger.info("Initialized " + this.getClass().getSimpleName());
    }
    
    /**
     * Wait for element to be visible
     * @param element WebElement to wait for
     * @return WebElement that is now visible
     */
    protected WebElement waitForVisibility(WebElement element) {
        wait.until(ExpectedConditions.visibilityOf(element));
        return element;
    }
    
    /**
     * Wait for element to be clickable
     * @param element WebElement to wait for
     * @return WebElement that is now clickable
     */
    protected WebElement waitForClickability(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
        return element;
    }
    
    /**
     * Click on element with wait
     * @param element WebElement to click
     */
    protected void click(WebElement element) {
        waitForClickability(element).click();
    }
    
    /**
     * Enter text in element with wait
     * @param element WebElement to enter text into
     * @param text Text to enter
     */
    protected void sendKeys(WebElement element, String text) {
        waitForVisibility(element).clear();
        element.sendKeys(text);
    }
    
    /**
     * Get text from element with wait
     * @param element WebElement to get text from
     * @return Text from element
     */
    protected String getText(WebElement element) {
        return waitForVisibility(element).getText();
    }
    
    /**
     * Check if element is displayed
     * @param element WebElement to check
     * @return true if element is displayed, false otherwise
     */
    protected boolean isDisplayed(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
