package com.testing.framework.api.base;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

/**
 * Base class for API tests providing common functionality
 * for request/response specifications and logging
 */
public class ApiBaseTest {
    protected static final Logger logger = LogManager.getLogger(ApiBaseTest.class);
    protected static RequestSpecification requestSpec;
    protected static ResponseSpecification responseSpec;
    protected static String token;
    protected static String userId;

    @BeforeClass
    public void setup() {
        // Base URI configuration
        RestAssured.baseURI = "https://reqres.in/api";
        
        // Request specification
        requestSpec = new RequestSpecBuilder()
                .setContentType(ContentType.JSON)
                .log(LogDetail.ALL)
                .build();
        
        // Response specification
        responseSpec = new ResponseSpecBuilder()
                .expectContentType(ContentType.JSON)
                .log(LogDetail.ALL)
                .build();
        
        // Set default request specification
        RestAssured.requestSpecification = requestSpec;
        RestAssured.responseSpecification = responseSpec;
        
        logger.info("API Base Test setup completed");
    }

    @AfterClass
    public void cleanup() {
        // Perform any necessary cleanup after tests
        if (userId != null) {
            logger.info("Cleaning up test user with ID: " + userId);
            // Cleanup code will be implemented here
        }
    }

    /**
     * Set authentication token for subsequent requests
     * @param authToken The authentication token
     */
    protected void setAuthToken(String authToken) {
        token = authToken;
        requestSpec = new RequestSpecBuilder()
                .setContentType(ContentType.JSON)
                .addHeader("Authorization", "Bearer " + token)
                .log(LogDetail.ALL)
                .build();
        RestAssured.requestSpecification = requestSpec;
        logger.info("Auth token set for subsequent requests");
    }

    /**
     * Log request details
     * @param endpoint API endpoint
     * @param method HTTP method
     * @param body Request body (optional)
     */
    protected void logRequest(String endpoint, String method, Object body) {
        logger.info("Request to: " + endpoint);
        logger.info("Method: " + method);
        if (body != null) {
            logger.info("Request Body: " + body.toString());
        }
    }

    /**
     * Log response details
     * @param response Response string
     */
    protected void logResponse(String response) {
        logger.info("Response: " + response);
    }
}
