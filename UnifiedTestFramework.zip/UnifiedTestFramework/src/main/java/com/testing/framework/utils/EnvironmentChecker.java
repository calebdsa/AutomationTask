package com.testing.framework.utils;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Utility class for environment checks
 */
public class EnvironmentChecker {
    
    /**
     * Check if a server is running at the specified URL
     * @param serverUrl URL to check
     * @param timeout Connection timeout in milliseconds
     * @return true if server is running, false otherwise
     */
    public static boolean isServerRunning(String serverUrl, int timeout) {
        try {
            URL url = new URL(serverUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(timeout);
            connection.setReadTimeout(timeout);
            connection.setRequestMethod("GET");
            
            try {
                connection.connect();
                return connection.getResponseCode() > 0;
            } catch (Exception e) {
                return false;
            } finally {
                connection.disconnect();
            }
        } catch (IOException e) {
            return false;
        }
    }
    
    /**
     * Check if a file exists at the specified path
     * @param filePath Path to the file
     * @return true if file exists, false otherwise
     */
    public static boolean doesFileExist(String filePath) {
        return new java.io.File(filePath).exists();
    }
    
    /**
     * Check if a directory exists at the specified path
     * @param dirPath Path to the directory
     * @return true if directory exists, false otherwise
     */
    public static boolean doesDirectoryExist(String dirPath) {
        java.io.File dir = new java.io.File(dirPath);
        return dir.exists() && dir.isDirectory();
    }
    
    /**
     * Create a directory if it doesn't exist
     * @param dirPath Path to the directory
     * @return true if directory exists or was created, false otherwise
     */
    public static boolean createDirectoryIfNotExists(String dirPath) {
        java.io.File dir = new java.io.File(dirPath);
        if (!dir.exists()) {
            return dir.mkdirs();
        }
        return true;
    }
}
