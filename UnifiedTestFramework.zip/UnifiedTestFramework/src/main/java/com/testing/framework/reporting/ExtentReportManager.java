package com.testing.framework.reporting;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Reporter class for generating ExtentReports
 */
public class ExtentReportManager {
    private static final Logger logger = LogManager.getLogger(ExtentReportManager.class);
    private static ExtentReports extent;
    private static Map<Long, ExtentTest> testMap = new HashMap<>();
    private static final String REPORT_PATH = "test-output/ExtentReport.html";
    
    /**
     * Initialize ExtentReports
     */
    public static synchronized void initReports() {
        if (extent == null) {
            // Create reports directory if it doesn't exist
            File reportsDir = new File("test-output");
            if (!reportsDir.exists()) {
                reportsDir.mkdirs();
            }
            
            // Initialize ExtentReports
            ExtentSparkReporter sparkReporter = new ExtentSparkReporter(REPORT_PATH);
            sparkReporter.config().setDocumentTitle("API-UI Integration Test Report");
            sparkReporter.config().setReportName("End-to-End Test Results");
            
            extent = new ExtentReports();
            extent.attachReporter(sparkReporter);
            extent.setSystemInfo("OS", System.getProperty("os.name"));
            extent.setSystemInfo("Java Version", System.getProperty("java.version"));
            
            logger.info("ExtentReports initialized");
        }
    }
    
    /**
     * Create a new test in the report
     * @param testName Name of the test
     * @return ExtentTest instance
     */
    public static synchronized ExtentTest createTest(String testName) {
        if (extent == null) {
            initReports();
        }
        
        ExtentTest test = extent.createTest(testName);
        testMap.put(Thread.currentThread().getId(), test);
        logger.info("Created test: " + testName);
        return test;
    }
    
    /**
     * Get the current test
     * @return ExtentTest instance for the current thread
     */
    public static synchronized ExtentTest getTest() {
        return testMap.get(Thread.currentThread().getId());
    }
    
    /**
     * Log a step in the report
     * @param status Status of the step
     * @param message Step message
     */
    public static synchronized void logStep(Status status, String message) {
        getTest().log(status, message);
        logger.info("Logged step: " + message);
    }
    
    /**
     * Add a screenshot to the report
     * @param screenshotPath Path to the screenshot file
     * @param title Title for the screenshot
     */
    public static synchronized void addScreenshot(String screenshotPath, String title) {
        try {
            getTest().addScreenCaptureFromPath(screenshotPath, title);
            logger.info("Added screenshot: " + title);
        } catch (Exception e) {
            logger.error("Failed to add screenshot: " + e.getMessage());
        }
    }
    
    /**
     * Flush the report to disk
     */
    public static synchronized void flushReports() {
        if (extent != null) {
            extent.flush();
            logger.info("ExtentReports flushed to disk");
        }
    }
}
