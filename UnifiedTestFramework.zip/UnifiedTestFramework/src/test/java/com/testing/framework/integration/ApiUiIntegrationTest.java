package com.testing.framework.integration;

import com.aventstack.extentreports.Status;
import com.testing.framework.api.models.User;
import com.testing.framework.api.services.UserApiService;
import com.testing.framework.mobile.base.MobileBaseTest;
import com.testing.framework.mobile.pages.LoginPage;
import com.testing.framework.mobile.pages.ProfilePage;
import com.testing.framework.reporting.ExtentReportManager;
import com.testing.framework.utils.DataValidator;
import com.testing.framework.utils.SchemaValidator;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * Integration test class that bridges API and UI testing
 * Creates a user via API, logs in with that user in the mobile app,
 * and validates that the profile data shown in the app matches the API response
 */
public class ApiUiIntegrationTest extends MobileBaseTest {
    private static final Logger logger = LogManager.getLogger(ApiUiIntegrationTest.class);
    private UserApiService userApiService;
    private User testUser;
    private Response userResponse;
    private boolean apiSetupComplete = false;
    
    @BeforeClass
    public void setup() {
        // Initialize ExtentReports
        ExtentReportManager.initReports();
        ExtentReportManager.createTest("API-UI Integration Test");
        ExtentReportManager.logStep(Status.INFO, "Setting up test environment");
        
        try {
            // Initialize API service
            userApiService = new UserApiService();
            
            // Create test user via API
            testUser = new User("John Doe", "QA Engineer", User.UserType.CREATE);
            testUser.setEmail("john.doe@example.com");
            testUser.setPassword("password123");
            
            ExtentReportManager.logStep(Status.INFO, "Creating test user via API");
            Response createResponse = userApiService.createUser(testUser);
            Assert.assertEquals(createResponse.getStatusCode(), 201, "User creation failed");
            
            // Validate create user response schema
            SchemaValidator.validateCreateUserSchema(createResponse);
            
            // Store user ID for cleanup
            testUser.setId(createResponse.jsonPath().getString("id"));
            logger.info("Test user created with ID: " + testUser.getId());
            
            // Get user details via API
            ExtentReportManager.logStep(Status.INFO, "Retrieving user details via API");
            userResponse = userApiService.getUserById(testUser.getId());
            Assert.assertEquals(userResponse.getStatusCode(), 200, "User retrieval failed");
            
            // Map API response to User object
            User apiUser = userApiService.mapResponseToUser(userResponse);
            testUser.setFirstName(apiUser.getFirstName());
            testUser.setLastName(apiUser.getLastName());
            testUser.setAvatar(apiUser.getAvatar());
            
            apiSetupComplete = true;
            ExtentReportManager.logStep(Status.PASS, "API setup completed successfully");
        } catch (Exception e) {
            logger.error("API setup failed: " + e.getMessage(), e);
            ExtentReportManager.logStep(Status.FAIL, "API setup failed: " + e.getMessage());
            throw e;
        }
    }
    
    @Test
    public void testApiUiIntegration() {
        // Skip test if API setup failed or driver is null
        if (!apiSetupComplete) {
            String message = "Skipping test because API setup was not completed successfully";
            logger.warn(message);
            ExtentReportManager.logStep(Status.SKIP, message);
            throw new SkipException(message);
        }
        
        if (driver == null) {
            String message = "Skipping test because Appium driver is not initialized";
            logger.warn(message);
            ExtentReportManager.logStep(Status.SKIP, message);
            throw new SkipException(message);
        }
        
        try {
            ExtentReportManager.logStep(Status.INFO, "Starting API-UI integration test");
            
            // Launch the mobile app and navigate to login page
            ExtentReportManager.logStep(Status.INFO, "Launching mobile app and navigating to login page");
            LoginPage loginPage = new LoginPage(driver);
            
            // Verify login page is displayed
            if (!loginPage.isLoginPageDisplayed()) {
                String message = "Login page is not displayed after app launch";
                logger.error(message);
                ExtentReportManager.logStep(Status.FAIL, message);
                Assert.fail(message);
            }
            
            // Login using the user created via API
            ExtentReportManager.logStep(Status.INFO, "Logging in with user created via API");
            ProfilePage profilePage = loginPage.login(testUser.getEmail(), testUser.getPassword());
            
            // Verify login was successful
            Assert.assertTrue(profilePage.isProfilePageDisplayed(), "Profile page is not displayed after login");
            ExtentReportManager.logStep(Status.PASS, "Login successful");
            
            // Capture screenshot of profile page
            String screenshotPath = captureScreenshot("profile_page");
            if (screenshotPath != null) {
                ExtentReportManager.addScreenshot(screenshotPath, "Profile Page");
            }
            
            // Validate profile data matches API response
            ExtentReportManager.logStep(Status.INFO, "Validating profile data against API response");
            
            // Get profile data from UI
            String uiUserId = profilePage.getUserId();
            String uiUserName = profilePage.getUserName();
            String uiUserEmail = profilePage.getUserEmail();
            String uiUserFirstName = profilePage.getUserFirstName();
            String uiUserLastName = profilePage.getUserLastName();
            
            // Create data maps for API and UI data
            Map<String, String> apiData = new HashMap<>();
            apiData.put("id", testUser.getId());
            apiData.put("name", testUser.getName());
            apiData.put("email", testUser.getEmail());
            apiData.put("firstName", testUser.getFirstName());
            apiData.put("lastName", testUser.getLastName());
            
            Map<String, String> uiData = new HashMap<>();
            uiData.put("id", uiUserId);
            uiData.put("name", uiUserName);
            uiData.put("email", uiUserEmail);
            uiData.put("firstName", uiUserFirstName);
            uiData.put("lastName", uiUserLastName);
            
            // Use DataValidator to validate consistency between API and UI data
            boolean dataConsistent = DataValidator.validateDataConsistency(apiData, uiData);
            Assert.assertTrue(dataConsistent, "Profile data in UI does not match API response");
            
            ExtentReportManager.logStep(Status.PASS, "Profile data validation successful");
            
            // Log detailed comparison results
            for (Map.Entry<String, String> entry : apiData.entrySet()) {
                String fieldName = entry.getKey();
                String apiValue = entry.getValue();
                String uiValue = uiData.get(fieldName);
                
                String comparisonResult = apiValue.equals(uiValue) ? "MATCH" : "MISMATCH";
                ExtentReportManager.logStep(
                    apiValue.equals(uiValue) ? Status.PASS : Status.FAIL,
                    String.format("Field: %s | API: %s | UI: %s | Result: %s", 
                                  fieldName, apiValue, uiValue, comparisonResult)
                );
            }
            
            // Logout from the app
            ExtentReportManager.logStep(Status.INFO, "Logging out from the app");
            loginPage = profilePage.clickLogout();
            Assert.assertTrue(loginPage.isLoginPageDisplayed(), "Login page is not displayed after logout");
            
            ExtentReportManager.logStep(Status.PASS, "API-UI integration test completed successfully");
        } catch (Exception e) {
            logger.error("Test execution failed: " + e.getMessage(), e);
            ExtentReportManager.logStep(Status.FAIL, "Test execution failed: " + e.getMessage());
            throw e;
        }
    }
    
    @AfterClass
    public void cleanup() {
        try {
            // Clean up test data via API
            if (apiSetupComplete && testUser != null && testUser.getId() != null) {
                ExtentReportManager.logStep(Status.INFO, "Cleaning up test user via API");
                Response deleteResponse = userApiService.deleteUser(testUser.getId());
                Assert.assertEquals(deleteResponse.getStatusCode(), 204, "User deletion failed");
                logger.info("Test user deleted successfully");
                ExtentReportManager.logStep(Status.PASS, "Test user cleanup successful");
            }
        } catch (Exception e) {
            logger.error("Test cleanup failed: " + e.getMessage(), e);
            ExtentReportManager.logStep(Status.FAIL, "Test cleanup failed: " + e.getMessage());
        } finally {
            // Flush extent reports
            ExtentReportManager.flushReports();
        }
    }
}
