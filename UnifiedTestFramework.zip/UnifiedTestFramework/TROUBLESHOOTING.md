# API-UI Integration Test Framework - Troubleshooting Guide

## Common Issues and Solutions

### 1. Appium Server Connection Issues

**Error Message:**
```
Connection refused: no further information
```

**Solution:**
- Ensure Appium server is running at the configured URL (default: http://localhost:4723/wd/hub)
- Check if the port is correct and not blocked by firewall
- Verify network connectivity between test machine and Appium server

**How to Start Appium Server:**
```bash
appium --address 127.0.0.1 --port 4723
```

### 2. Missing App File

**Error Message:**
```
App file not found at: [path]/src/test/resources/apps/TheApp.apk
```

**Solution:**
- Ensure the app file exists at the specified location
- Download the sample app if needed:
  - For Android: https://github.com/saucelabs/sample-app-mobile/releases/download/2.7.1/Android-MyDemoAppRN.apk
- Place the app file in the correct directory: `src/test/resources/apps/`

### 3. Android Emulator or Device Not Available

**Error Message:**
```
Could not find a connected Android device
```

**Solution:**
- Ensure Android emulator is running or physical device is connected
- Verify device is visible with `adb devices` command
- Check USB debugging is enabled on physical devices

### 4. API Connection Issues

**Error Message:**
```
Connection timed out or Connection refused when calling API
```

**Solution:**
- Check internet connectivity
- Verify API endpoint is accessible (https://reqres.in/api)
- Check if any proxy settings are needed for your network

## Environment Setup Checklist

Before running tests, ensure:

1. ✅ Java 11 or higher is installed
2. ✅ Maven is installed and configured
3. ✅ Appium server is running
4. ✅ Android SDK is installed (for Android tests)
5. ✅ Android emulator is running or physical device is connected
6. ✅ App file is available in the correct location
7. ✅ Internet connectivity for API calls

## Running Tests with Environment Validation

The framework now includes environment validation checks that will:
- Verify Appium server is running before attempting to connect
- Check if the app file exists before starting tests
- Skip UI tests if environment is not ready while still running API tests
- Provide clear error messages with troubleshooting steps

## Logging

Logs are available in:
- Console output
- `logs/test.log` file
- ExtentReports HTML report in `test-output/ExtentReport.html`
