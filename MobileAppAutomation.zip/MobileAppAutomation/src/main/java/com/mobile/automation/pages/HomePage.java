package com.mobile.automation.pages;

import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;

public class HomePage extends BasePage {
    private final By cartButton = By.id("cartBtn");
    private final By itemList = By.id("itemList");
    private final By addToCartButton = By.id("addToCartBtn");
    private final By logoutButton = By.id("logoutBtn");

    public HomePage(AndroidDriver driver) {
        super(driver);
    }

    public void addItemToCart(String itemName) {
        By itemLocator = By.xpath("//android.widget.TextView[@text='" + itemName + "']");
        click(itemLocator);
        click(addToCartButton);
    }

    public void openCart() {
        click(cartButton);
    }

    public boolean isItemInCart(String itemName) {
        By itemLocator = By.xpath("//android.widget.TextView[@text='" + itemName + "']");
        return isElementDisplayed(itemLocator);
    }

    public void logout() {
        click(logoutButton);
    }
} 