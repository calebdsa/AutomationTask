package com.mobile.automation.listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.OutputType;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TestListener implements ITestListener {
    private static final ExtentReports extent = new ExtentReports();
    private static final ExtentSparkReporter spark = new ExtentSparkReporter("test-output/extent-report.html");
    private static final ThreadLocal<ExtentTest> test = new ThreadLocal<>();

    static {
        extent.attachReporter(spark);
    }

    @Override
    public void onTestStart(ITestResult result) {
        ExtentTest extentTest = extent.createTest(result.getMethod().getMethodName());
        test.set(extentTest);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        test.get().log(Status.PASS, "Test passed: " + result.getMethod().getMethodName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        test.get().log(Status.FAIL, "Test failed: " + result.getMethod().getMethodName());
        
        if (result.getTestContext().getAttribute("driver") instanceof AndroidDriver) {
            AndroidDriver driver = (AndroidDriver) result.getTestContext().getAttribute("driver");
            takeScreenshot(driver, result.getMethod().getMethodName());
        }
    }

    @Override
    public void onFinish(ITestContext context) {
        extent.flush();
    }

    private void takeScreenshot(AndroidDriver driver, String testName) {
        try {
            File screenshot = driver.getScreenshotAs(OutputType.FILE);
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            Path screenshotPath = Paths.get("test-output/screenshots", testName + "_" + timestamp + ".png");
            Files.createDirectories(screenshotPath.getParent());
            Files.copy(screenshot.toPath(), screenshotPath);
            test.get().addScreenCaptureFromPath(screenshotPath.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
} 