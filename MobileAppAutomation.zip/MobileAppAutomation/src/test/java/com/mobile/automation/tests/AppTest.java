package com.mobile.automation.tests;

import com.mobile.automation.config.AppiumConfig;
import com.mobile.automation.pages.HomePage;
import com.mobile.automation.pages.LoginPage;
import io.appium.java_client.android.AndroidDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class AppTest {
    private AndroidDriver driver;
    private LoginPage loginPage;
    private HomePage homePage;

    @BeforeMethod
    public void setup() throws Exception {
        driver = AppiumConfig.getDriver();
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
    }

    @Test
    public void testLoginAndCartFlow() {
        // Login
        loginPage.login("testuser", "password123");
        Assert.assertFalse(loginPage.isErrorMessageDisplayed(), "Login failed");

        // Add item to cart
        String itemName = "Sample Item";
        homePage.addItemToCart(itemName);

        // Verify item in cart
        homePage.openCart();
        Assert.assertTrue(homePage.isItemInCart(itemName), "Item not found in cart");

        // Logout
        homePage.logout();
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
} 