# Mobile App Automation Framework

This project implements an automated testing framework for mobile applications using Appium, Java, and TestNG.

## Prerequisites

- Java JDK 11 or higher
- Maven
- Appium Server
- Android SDK
- Android Emulator or physical device
- TheApp.apk (Sauce Labs sample app)

## Setup Instructions

1. Install Appium Server:
   ```bash
   npm install -g appium
   ```

2. Install Appium Doctor to verify setup:
   ```bash
   npm install -g appium-doctor
   appium-doctor
   ```

3. Start Appium Server:
   ```bash
   appium
   ```

4. Install the test app:
   ```bash
   adb install TheApp.apk
   ```

## Project Structure

```
src/
├── main/java/com/mobile/automation/
│   ├── config/
│   │   └── AppiumConfig.java
│   ├── pages/
│   │   ├── BasePage.java
│   │   ├── LoginPage.java
│   │   └── HomePage.java
│   └── listeners/
│       └── TestListener.java
└── test/java/com/mobile/automation/
    └── tests/
        └── AppTest.java
```

## Running Tests

1. Start the Android emulator or connect a physical device
2. Start the Appium server
3. Run the tests using Maven:
   ```bash
   mvn clean test
   ```

## Test Reports

After test execution, you can find the test reports in:
- Extent Reports: `test-output/extent-report.html`
- Screenshots: `test-output/screenshots/`

## Features

- Page Object Model (POM) implementation
- Parallel test execution support
- Screenshot capture on test failure
- ExtentReports integration
- Logging support
- Cross-platform support (Android) 