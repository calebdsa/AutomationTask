package com.api.testing.tests;

import com.api.testing.utils.SchemaValidator;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import org.json.JSONObject;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class UserTests {

    @Test
    public void testGetUserById() {
        // Set the base URI
        RestAssured.baseURI = "https://reqres.in/api";

        // Perform the GET request for user with ID 2
        Response response = given()
                .when()
                .get("/users/2");

        // Validate the status code
        response.then().statusCode(200);

        // Validate the response schema using the SchemaValidator utility
        SchemaValidator.validateUserSchema(response);
    }

    @Test
    public void testCreateUser() {
        // Set the base URI
        RestAssured.baseURI = "https://reqres.in/api";

        // Create a JSON object for the new user
        JSONObject requestParams = new JSONObject();
        requestParams.put("name", "morpheus");
        requestParams.put("job", "leader");

        // Perform the POST request
        Response response = given()
                .header("Content-Type", "application/json")
                .header("x-api-key", "reqres-free-v1")
                .body(requestParams.toString())
                .when()
                .post("/users");

        // Validate the status code
        response.then().statusCode(201);

        // Validate the response schema using the SchemaValidator utility
        SchemaValidator.validateCreateUserSchema(response);
    }

    @Test
    public void testUpdateUser() {
        // Set the base URI
        RestAssured.baseURI = "https://reqres.in/api";

        // Create a JSON object with updated user data
        JSONObject requestParams = new JSONObject();
        requestParams.put("name", "morpheus");
        requestParams.put("job", "zion resident");

        // Perform the PUT request to update user with ID 2
        Response response = given()
                .header("Content-Type", "application/json")
                .header("x-api-key", "reqres-free-v1")
                .body(requestParams.toString())
                .when()
                .put("/users/2");

        // Validate the status code
        response.then().statusCode(200);

        // Validate response body fields based on provided example
        response.then().body("name", equalTo("morpheus"));
        response.then().body("job", equalTo("zion resident"));
        response.then().body("updatedAt", notNullValue()); // Check if updatedAt field exists
    }

    @Test
    public void testDeleteUser() {
        // Set the base URI
        RestAssured.baseURI = "https://reqres.in/api";

        // Perform the DELETE request for user with ID 2
        Response response = given()
                .header("x-api-key", "reqres-free-v1")
                .when()
                .delete("/users/2");

        // Validate the status code
        response.then().statusCode(204);

        // reqres.in returns an empty response for DELETE, so no schema validation needed
    }

    @Test
    public void testLoginAndUseToken() {
        // Set the base URI
        RestAssured.baseURI = "https://reqres.in/api";

        // Create JSON object for login credentials
        JSONObject loginCredentials = new JSONObject();
        loginCredentials.put("email", "eve.holt@reqres.in");
        loginCredentials.put("password", "cityslicka");

        // Perform the login POST request
        Response loginResponse = given()
                .header("Content-Type", "application/json")
                .header("x-api-key", "reqres-free-v1")
                .body(loginCredentials.toString())
                .when()
                .post("/login");

        // Validate login status code and extract token
        loginResponse.then().statusCode(200);
        String token = loginResponse.jsonPath().getString("token");

        // Use the extracted token in a subsequent GET request (e.g., get user with ID 2)
        Response getUserResponse = given()
                .header("Authorization", "Bearer " + token)
                .header("x-api-key", "reqres-free-v1")
                .when()
                .get("/users/2");

        // Validate the status code of the GET request
        getUserResponse.then().statusCode(200);

        // Optionally, validate the schema of the GET response
        SchemaValidator.validateUserSchema(getUserResponse);
    }

    @Test
    public void testListUsers() {
        // Set the base URI
        RestAssured.baseURI = "https://reqres.in/api";

        // Perform the GET request for listing users on page 2
        Response response = given()
                .when()
                .get("/users?page=2");

        // Validate the status code
        response.then().statusCode(200);

        // Validate the response schema using the SchemaValidator utility
        SchemaValidator.validateListUsersSchema(response);
    }
} 